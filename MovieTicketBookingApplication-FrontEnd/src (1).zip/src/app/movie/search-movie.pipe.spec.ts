import { SearchMoviePipe } from './search-movie.pipe';

describe('SearchMoviePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchMoviePipe();
    expect(pipe).toBeTruthy();
  });
});
